import styled from "styled-components";

const UserPageWrapper = styled.section`
  a {
    text-decoration: none;
  }

  header {
    .container {
      display: flex;
      flex-direction: row;
      justify-content: space-between;
      align-items: center;
      .logo {
        width: max-content;
      }
      .searchbar {
        position: relative;
        padding: 10px 0;
        display: flex;
        width: 300px;
        align-content: center;
        justify-content: center;
        height: 70px;
        .search-icon {
          position: absolute;
          top: 28px;
          right: 15px;
        }
      }
      .user-login {
        .dropdown-toggle {
          display: flex;
          background: transparent;
          border: none;
          color: black;
          justify-content: center;
          align-items: center;
          height: 40px;
          &::after {
            content: none !important;
          }
          .user-avatar {
            margin-bottom: 15px;
            border: 2px solid #000;
            padding: 1px 1px 0;

            border-radius: 50%;
            margin-right: 10px;
          }
        }
      }
    }
  }
  main {
    .top-to-btm {
      position: relative;
      .icon-position {
        position: fixed;
        bottom: 40px;
        right: 25px;
        z-index: 20;
      }
      .icon-style {
        border: 0;
        border-radius: 50%;
        background: #ffffff;
        height: 50px;
        width: 50px;
        color: #f9e752;
        cursor: pointer;
        animation: movebtn 3s ease-in-out infinite;
        transition: all 0.5s ease-in-out;
      }
      .icon-style:hover {
        animation: none;
      }
    }
  }
  footer {
    background: #2c2c2c;
    height: 300px;
    a {
      color: #dedede;
    }
    .card-footer {
      display: flex;
      flex-direction: column;
      .row {
        display: grid;
        grid-template-columns: repeat(3, 1fr);
        gap: 5px;
      }
      p {
        color: #dedede;
      }
      .icons {
        display: flex;
        align-items: start;
        flex-direction: row;
        gap: 35px;
        .icon {
          fill: #dedede;
        }
      }
    }
  }
`;

export default UserPageWrapper;
