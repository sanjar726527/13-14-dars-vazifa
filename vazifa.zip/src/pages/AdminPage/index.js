import React from 'react'

export const AdminPage = () => {
  return (
    <div>index</div>
  )
}
