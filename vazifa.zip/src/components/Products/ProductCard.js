import React, { useState } from "react";
import { Link } from "react-router-dom";
import ProductContext from "../../useContext/ProductContext";
import { Basket } from "../Basket";

export const ProductCard = ({ product }) => {
  const [cart, setCart] = useState([]);
  console.log(cart);
  return (
    <ProductContext.Provider value={cart}>
      <div className="card-row">
        {product.map((item, index) => (
          <div className="card" key={index}>
            <img src={item.img} alt="image" />
            <span className="active">
              <Link
                onClick={() => {
                  setCart([...cart, item]);
                }}
                className="btn btn-warning"
                to={`/user/soups/${index}`}
              >
                Add
              </Link>
            </span>
            <h3>{item.title}</h3>
            <p>{item.price} sum</p>
          </div>
        ))}
      </div>
      {cart.length > 0 && <Basket />}
    </ProductContext.Provider>
  );
};
