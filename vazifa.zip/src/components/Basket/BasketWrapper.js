import styled from "styled-components";

const BasketWrapper = styled.section`
  position: absolute;
  background: white;
  width: 80%;
  max-width: 1184px;
  margin: 0 auto;
  height: 60px;
  border: 1px solid #333333;
  border-radius: 10px;
  color: black;
  margin-top: 20px;
`;

export default BasketWrapper;
