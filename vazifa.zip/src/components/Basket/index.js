import React, { useContext } from "react";
import ProductContext from "../../useContext/ProductContext";
import BasketWrapper from "./BasketWrapper";

export const Basket = () => {
  const cart = useContext(ProductContext);
  console.log(cart);

  return (
    <BasketWrapper>
      <div className="container">
        {cart.map((e, i) => {
          return <h1 key={i}>{e.title}</h1>;
        })}
        <p>{cart.price}</p>
      </div>
    </BasketWrapper>
  );
};
