import React from "react";
import image from "../../assets/Rectangle.png";
import image1 from "../../assets/Rectangle6.png";
import image2 from "../../assets/Rectangle4.png";
import image3 from "../../assets/Rectangle5.png";
import MainHeaderWrapper from "./MainHeaderWrapper";

export const MainHeader = () => {
  return (
    <MainHeaderWrapper>
      <div className="container">
        <div className="row">
        <div className="item">
            <img src={image} alt="image" />
          </div>
          <div className="item1">
            <img src={image1} alt="image" />
          </div>
          <div className="item2">
            <img src={image2} alt="image" />
          </div>
          <div className="item3">
            <img src={image3} alt="image" />
          </div>
        </div>
      </div>
    </MainHeaderWrapper>
  );
};
