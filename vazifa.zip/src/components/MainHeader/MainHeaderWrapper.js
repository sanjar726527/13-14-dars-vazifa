import styled from "styled-components";

const MainHeaderWrapper = styled.section`
  background: #ffec00;
  height: 546px;
  max-width: 1444px;
  margin: 0 auto;
  overflow: hidden;
  .container {
    .row {
      display: flex;
      flex-direction: row;
      justify-content: center;
      align-items: center;
      margin-left: 120px;
      z-index: 10;
      position: relative;
      padding: 0;
      .item {
        position: absolute;
        right: 450px;
        bottom: -1px;
      }
      .item1 {
        position: absolute;
        right: 230px;
        bottom: 50px;
      }
      .item3 {
        position: absolute;
        left: 768px;
        bottom: 13px;
      }
    }
  }
`;

export default MainHeaderWrapper;
