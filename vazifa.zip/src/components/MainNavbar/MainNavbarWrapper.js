import styled from "styled-components";

const MainNavbarWrapper = styled.section`
padding: 43px 0;
  .container {
    display: flex;
    flex-direction: row;
    gap: 10px;
  }
`;

export default MainNavbarWrapper;
