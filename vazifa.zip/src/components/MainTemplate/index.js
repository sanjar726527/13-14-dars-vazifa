import React from "react";
import MainTemplateWrapper from "./MainTemplateWrapper";

export const MainTemplate = ({ children }) => {
  return (
    <MainTemplateWrapper>
      <div className="container">{children}</div>
      
    </MainTemplateWrapper>
  );
};
