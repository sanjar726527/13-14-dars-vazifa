import React from "react";
import { Route, Routes } from "react-router-dom";
import { AllProducts } from "./components/Products/AllProducts";
import { Drinks } from "./components/Products/Drinks";
import { Salads } from "./components/Products/Salads";
import { Soups } from "./components/Products/Soups";
import { HomePage } from "./pages/HomePage";
import { UserPage } from "./pages/UserPage";

function App() {
  return (
    <Routes>
      <Route path="/" element={<HomePage />} />
      <Route path="/user" element={<UserPage />}>
        <Route path="" element={<AllProducts />} />
        <Route path="salads/*" element={<AllProducts />} />
        <Route path="soups/*" element={<AllProducts />} />
        <Route path="drinks/*" element={<AllProducts />} />
      </Route>
    </Routes>
  );
}

export default App;
